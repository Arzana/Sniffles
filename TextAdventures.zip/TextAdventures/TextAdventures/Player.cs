﻿using System;

namespace TextAdventures
{
    public class Player : Actor
    {
        public uint XPosition;
        public uint YPosition;

        public Player()
            :base("Bob")
        {
            XPosition = 0;
            YPosition = 0;
        }

        public Player(string name, int maxHealth)
            :base(name, maxHealth)
        {
            XPosition = 0;
            YPosition = 0;
        }

        public void Move(Map map, string direction)
        {
            switch (direction)
            {
                case (Program.MOVE_NORTH):
                    YPosition += 1;
                    break;
                case (Program.MOVE_EAST):
                    XPosition += 1;
                    break;
                case (Program.MOVE_SOUTH):
                    YPosition -= 1;
                    break;
                case (Program.MOVE_WEST):
                    XPosition -= 1;
                    break;
                default:
                    throw new ArgumentException("You cannot move in that direction!");
            }
        }
    }
}