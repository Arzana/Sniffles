﻿using System;

namespace TextAdventures.Items
{
    public class Bread : Item
    {
        public Bread()
            :base()
        {
        }

        public override void Desciption()
        {
            Console.WriteLine("You see a loaf of bread.");
        }
    }
}
