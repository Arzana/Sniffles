﻿using System;

namespace TextAdventures.Items
{
    public class Diamond : Item
    {
        public Diamond()
            : base("Diamond")
        {

        }

        public override void Desciption()
        {
            Console.WriteLine("You see a shining diamond lying on the ground.");
        }
    }
}