﻿using TextAdventures.Items;

namespace TextAdventures.Enemy
{
    public class FacelessMonster : Actor
    {
        public FacelessMonster()
            : base("The faceless", 100)     // Create a new actor with a specified name and health.
        {
            AddItem(new Diamond());         // Add a diamond to the inventory.    
        }
    }
}