﻿using System;

namespace TextAdventures.Enemy
{
    public class Rat : Actor
    {
        public Rat()
            : base("Rat", 10, 1)            // Create a new actor with a specified name, health and damage.
        {
        }

        public override void Description()  // Create a custom description for the rat.
        {
            Console.WriteLine("You see a rat.");
        }
    }
}
