﻿using TextAdventures.Enemy;

namespace TextAdventures.Locations
{
    public class R_lyeh : Location
    {
        public R_lyeh()
            :base()
        {
            AddEnemy(new FacelessMonster());
        }
    }
}