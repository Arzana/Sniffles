﻿using System;
using TextAdventures.Enemy;

namespace TextAdventures.Locations
{
    public class Basement : Location
    {
        public Basement()
            :base("Grandma's basement")
        {
            AddEnemy(new Rat());        // Add a enemy to the location.
        }

        public override void Description()
        {
            Console.WriteLine("A foul and dark place.");
            Console.WriteLine("It might have rats!");
        }
    }
}