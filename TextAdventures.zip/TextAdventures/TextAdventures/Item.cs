﻿using System;

namespace TextAdventures
{
    public abstract class Item
    {
        public string Name;

        public Item()
        {
            Name = "Bread";
        }

        public Item(string name)
        {
            Name = name;
        }

        public virtual void Desciption()
        {
            Console.WriteLine("You see a strange item.");
        }
    }
}