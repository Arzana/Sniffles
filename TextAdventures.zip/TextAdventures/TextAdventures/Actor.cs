﻿using System;
using System.Collections.Generic;

namespace TextAdventures
{
    public abstract class Actor
    {
        public string Name;
        public int MaxHealth;
        public int Health;
        public int Damage;

        private List<Item> inventory = new List<Item>();

        public Actor()
        {
            Name = "The Unnamable";
            MaxHealth = 100;
            Health = 100;
            Damage = 10;
        }

        public Actor(string name)
        {
            Name = name;
            MaxHealth = 100;
            Health = 100;
            Damage = 10;
        }

        public Actor(string name, int maxHealth)
        {
            Name = name;
            MaxHealth = maxHealth;
            Health = maxHealth;
            Damage = 10;
        }

        public Actor(string name, int maxHealth, int damage)
        {
            Name = name;
            MaxHealth = maxHealth;
            Health = maxHealth;
            Damage = damage;
        }

        /// <summary> Perfrom an attack on a specified enemy. </summary>
        public void Attack(Actor enemy)
        {
            enemy.Health -= Damage;
        }

        public bool IsAlive()
        {
            return Health > 0;
        }

        public virtual void Description()
        {
            Console.WriteLine("You see a monster of unspeakable horror!");
        }

        /// <summary> Adds an item to the inventory. </summary>
        public void AddItem(Item item)
        {
            inventory.Add(item);
        }

        /// <summary>
        /// Checks if the actor has the specified item in his/her inventory.
        /// </summary>
        public bool HasItem(string name)
        {
            foreach (Item item in inventory)
            {
                if (item.Name == name)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Drops a specified item.
        /// </summary>
        public Item DropItem(string name)
        {
            for (int i = 0; i < inventory.Count; i++)
            {
                Item currentItem = inventory[i];

                if (currentItem.Name == name)
                {
                    inventory.Remove(currentItem);
                    return currentItem;
                }
            }

            return null;    // If no item was found return nothing.
        }

        /// <summary>
        /// Drops a random item.
        /// </summary>
        public Item DropRandomItem()
        {
            if (inventory.Count > 0)
            {
                int random = Program.RandomNumberGenerator.Next(0, inventory.Count);

                Item item = inventory[random];
                inventory.Remove(item);

                return item;
            }
            else    // If the inventory is empty return nothing.
            {
                return null;
            }
        }

        public void ShowInventory()
        {
            Console.WriteLine("The inventory contains:");

            foreach (Item item in inventory)
            {
                // the "\t" is a tab.
                Console.WriteLine("\t- {0}", item.Name);
            }
        }
    }
}
