﻿using System;
using System.Collections.Generic;
using TextAdventures.Locations;

/* -------------------------------- *
 | Originally made by Sietse Dijks  |
 | Releasedate: 18-01-2014          |
 |                                  |
 | Current version: 2.0             | 
 | Mady by:                         |
 |  - Joëll Stehouwer               | 
 |  - Frank de Jong                 |
 | Change date: 04-02-2015          |
 * -------------------------------- */

namespace TextAdventures
{
    public class Program
    {
        // Define the directions available to the player.
        public const string MOVE_NORTH = "Go North";
        public const string MOVE_EAST = "Go East";
        public const string MOVE_SOUTH = "Go South";
        public const string MOVE_WEST = "Go West";

        // Define alternative menu options.
        public const string ACTION_SEARCH = "Search";
        public const string ACTION_FIGHT = "Fight";
        public const string ACTION_RUN = "Run";
        public const string ACTION_QUIT = "Quit";

        // Intialize global random number generator.
        public static Random RandomNumberGenerator = new Random();
        public static bool exit;

        public static Player player;
        public static Map map;

        public static void Main(string[] args)
        {
            // Welcome the user.
            Console.WriteLine("Welcome to the text-based adventure.");
            Console.ReadKey();

            string name = string.Empty;

            // Check for correct name
            do
            {
                Console.Clear();
                Console.WriteLine("Before you can start your journey, you will have to enter your name.");
                Console.Write("Name: ");
                name = Console.ReadLine();

                Console.WriteLine("Is this correct? (Y/N)");
            } while (Console.ReadKey(true).Key != ConsoleKey.Y);

            // Inialize the player.
            player = new Player(name, 100);
            InitializeMap();

            // Start the game loop.
            GameLoop();
        }

        public static void InitializeMap()
        {
            // Add the locations with their specified coördinates to the map.
            map = new Map(3, 3);

            map.AddLocation(new Basement(), 0, 0);
            map.AddLocation(new R_lyeh(), 1, 0);
        }

        public static void ShowIntro()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the world of Flightwood.");
            Console.WriteLine("You just woke up from a cookie induced coma.");
            Console.WriteLine("You can't really remember anything but your name.");
            Console.WriteLine("Which by the way is {0}.", player.Name);

            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("You look around and you realise that you're in {0}.", map.GetCurrentLocation(player).Name);
            Console.WriteLine("You slowly come to your senses and choose to go.");
            Console.WriteLine("Press a key to continue . . .");
            Console.ReadKey();
        }

        public static void GameLoop()
        {
            ShowIntro();

            while (!exit)
            {
                Tick();
            }

            ShowOutro();
        }

        public static void Tick()
        {
            List<string> menuItems = new List<string>();
            int choice = ShowMenu(ref menuItems);

            switch (menuItems[choice])
            {
                case (MOVE_NORTH):
                case (MOVE_EAST):
                case (MOVE_SOUTH):
                case (MOVE_WEST):
                    // If any of the available directions have been chosen.
                    player.Move(map, menuItems[choice]);
                    break;
                case (ACTION_SEARCH):
                    // Add code to perform an item pickup.
                    break;
                case (ACTION_FIGHT):
                    // Add code for fighting here.
                    break;
                case (ACTION_RUN):
                    // Add code for running here.
                    break;
                case (ACTION_QUIT):
                    exit = true;
                    break;

            }
        }

        public static int ShowMenu(ref List<string> menuItems)
        {
            AddDirection(ref menuItems);

            // Save the current location for future use.
            Location currentLocation = map.GetCurrentLocation(player);

            // If the current location has at least one item add the option to search to the menu.
            if (currentLocation.HasItem())
            {
                menuItems.Add(ACTION_SEARCH);
            }

            // If the current location has at lease one enemy add the option to attack and run to the menu.
            if (currentLocation.HasEnemy())
            {
                menuItems.Add(ACTION_FIGHT);
                menuItems.Add(ACTION_RUN);
            }

            menuItems.Add(ACTION_QUIT);

            int choice = 0;
            string input = string.Empty;

            do
            {
                Console.Clear();
                map.GetCurrentLocation(player).Description();   // Show the current locations description.

                // Show all the menu options.
                for (int i = 0; i < menuItems.Count; i++)
                {
                    Console.WriteLine("{0} - {1}", i + 1, menuItems[i]);
                }

                Console.WriteLine("What will you do next? (1 - {0})", menuItems.Count);
                input = Console.ReadLine();
            } while (!int.TryParse(input, out choice) || (choice > menuItems.Count) || choice < 0);

            // Return the choice as an index value.
            return choice - 1;
        }

        public static void AddDirection(ref List<string> menuItems)
        {
            if (map.GetNorth(player))
            {
                menuItems.Add(MOVE_NORTH);
            }

            if (map.GetEast(player))
            {
                menuItems.Add(MOVE_EAST);
            }

            if (map.GetSouth(player))
            {
                menuItems.Add(MOVE_SOUTH);
            }

            if (map.GetWest(player))
            {
                menuItems.Add(MOVE_WEST);
            }
        }

        public static void ShowOutro()
        {
            Console.Clear();
            Console.WriteLine("Thank you for playing and have a nice day!");
            Console.WriteLine("Press a key to exit . . .");
            Console.ReadKey();
        }
    }
}