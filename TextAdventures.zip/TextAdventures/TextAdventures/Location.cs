﻿using System;
using System.Collections.Generic;

namespace TextAdventures
{
    public abstract class Location
    {
        public string Name;

        private List<Item> items = new List<Item>();
        private List<Actor> enemies = new List<Actor>();

        public Location()
        {
            Name = "R'lyeh";
        }

        public Location(string name)
        {
            Name = name;
        }

        public virtual void Description()
        {
            Console.WriteLine("You see a city, there is too much water.");
            Console.WriteLine("If you had to give it a score it would be a 7/10.");
        }

        public bool HasItem()
        {
            return items.Count > 0;
        }

        public bool HasEnemy()
        {
            return enemies.Count > 0;
        }

        public void AddItem(Item item)
        {
            items.Add(item);
        }

        public void AddEnemy(Actor enemy)
        {
            enemies.Add(enemy);
        }

        public Item GetRandomItem()
        {
            if (HasItem())
            {
                int random = Program.RandomNumberGenerator.Next(0, items.Count);

                Item item = items[random];
                items.Remove(item);

                return item;
            }
            else
            {
                return null;
            }
        }

        public Actor GetRandomEnemy()
        {
            if (HasEnemy())
            {
                int random = Program.RandomNumberGenerator.Next(0, enemies.Count);

                Actor enemy = enemies[random];
                enemies.Remove(enemy);

                return enemy;
            }
            else
            {
                return null;
            }
        }
    }
}