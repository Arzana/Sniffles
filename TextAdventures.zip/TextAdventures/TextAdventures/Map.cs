﻿using System;

namespace TextAdventures
{
    public class Map
    {
        public uint Height;
        public uint Width;

        private Location[,] map;

        public Map()
        {
            Height = 3;
            Width = 3;
            map = new Location[Width, Height];
        }

        public Map(uint width, uint height)
        {
            Width = width;
            Height = height;
            map = new Location[Width, Height];
        }

        public void AddLocation(Location location, uint x, uint y)
        {
            if (x < map.GetLength(0) && y < map.GetLength(1))
            {
                map[y, x] = location;
            }
            else
            {
                throw new ArgumentException("You cannot place a location outside of the map!");
            }
        }

        public Location GetCurrentLocation(Player player)
        {
            if (HasLocationAt(player.XPosition, player.YPosition))
            {
                return map[player.XPosition, player.YPosition];
            }
            else
            {
                throw new ArgumentException("Player is outside of the map");
            }
        }

        public bool GetNorth(Player player)
        {
            uint newX = player.XPosition;
            uint newY = player.YPosition + 1;

            return HasLocationAt(newX, newY);
        }

        public bool GetEast(Player player)
        {
            uint newX = player.XPosition + 1;
            uint newY = player.YPosition;

            return HasLocationAt(newX, newY);
        }

        public bool GetSouth(Player player)
        {
            uint newX = player.XPosition;
            uint newY = player.YPosition - 1;

            return HasLocationAt(newX, newY);
        }

        public bool GetWest(Player player)
        {
            uint newX = player.XPosition - 1;
            uint newY = player.YPosition;

            return HasLocationAt(newX, newY);
        }

        private bool HasLocationAt(uint x, uint y)
        {
            if (x < map.GetLength(0) && y < map.GetLength(1))   // Check if x and y are inside of the map.
            {
                Location location = map[x, y];                  // Get the location at (x,y).
                return location != null;                        // If the location was not initialized retun false otherwise return true.
            }
            else
            {
                return false;
            }
        }
    }
}